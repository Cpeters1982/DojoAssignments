function Circle(cx, cy, r, html_id){

    var html_id = html_id;
    this.info = { cx: cx,  cy: cy , r: r};
    
    //private function that generates a random number
    var randomNumberBetween = function(min, max){
        return Math.random()*(max-min) + min;
    }

    this.initialize = function(){
        //give a random velocity for the circle
        this.info.velocity = {
            x: randomNumberBetween(-4,4),
            y: randomNumberBetween(-4,4)
        }

        //create a circle 
        var circle = makeSVG('circle', 
            { 	cx: this.info.cx,
                cy: this.info.cy,
                r:  this.info.r,
                id: html_id,
                style: "fill: black"
            });

        document.getElementById('svg').appendChild(circle);
    }

    this.update = function(time){
        var el = document.getElementById(html_id);

        //see if the circle is going outside the browser. if it is, reverse the velocity
        if( this.info.cx > document.body.clientWidth - this.info.r || this.info.cx < 0 + this.info.r)
        {
            this.info.velocity.x = this.info.velocity.x * -1;
        }
        if( this.info.cy > document.body.clientHeight - this.info.r || this.info.cy < 0 + this.info.r)
        {
            this.info.velocity.y = this.info.velocity.y * -1;
        }

        this.info.cx = this.info.cx + this.info.velocity.x*time;
        this.info.cy = this.info.cy + this.info.velocity.y*time;

        el.setAttribute("cx", this.info.cx);
        el.setAttribute("cy", this.info.cy);
        var currentRadius = el.getAttribute("r");
        
        if (currentRadius < this.info.r){
            console.log("currentRadius: " + currentRadius);
            var newRadius = (Number(currentRadius) + 1);
            console.log(newRadius);
            el.setAttribute("r", newRadius);
            
        }
        
    }

    //creates the SVG element and returns it
    var makeSVG = function(tag, attrs) {
        var el= document.createElementNS('http://www.w3.org/2000/svg', tag);
        for (var k in attrs)
        {
            el.setAttribute(k, attrs[k]);
        }
        return el;
    }
    this.remove = function() {
        var circle = document.getElementById(html_id);
        var parent = circle.parentNode;
        parent.removeChild(circle);
    }

    this.initialize();
}

function PlayGround(){
    var counter = 0;  //counts the number of circles created
    var circles = [ ]; //array that will hold all the circles created in the app

    //a loop that updates the circle's position on the screen
    this.loop = function(){
        bounceOnCollision();
        for(circle in circles)
        {
            circles[circle].update(1);
            
        }
    }

    this.createNewCircle = function(x,y,r){
        
        var new_circle = new Circle(x,y,r, counter++);
        circles.push(new_circle);
        // console.log('created a new circle!', new_circle);
    }

    //create one circle when the game starts
    this.createNewCircle(document.body.clientWidth/2, document.body.clientHeight/2, 10);

    //set the SVG to the window size at starts
    setSVGsize();

    //need to check collisions between circles
    // function removeCirclesOnCollision(){
    //     for (var outerIndex = 0; outerIndex < circles.length - 1; outerIndex ++){
    //         for (var innerIndex = outerIndex + 1; innerIndex <= circles.length - 1; innerIndex++){
    //             var circle1Info = circles[outerIndex].info;
    //             var circle2Info = circles[innerIndex].info;
    //             if (distance([circle1Info.cx, circle1Info.cy],[circle2Info.cx, circle2Info.cy]) < circles[outerIndex].info.r + circles[innerIndex].info.r){
    //                 //circle collision event
    //                 console.log("detected collision - removing");
    //                 //remove both circles from document
    //                 circles[innerIndex].remove();
    //                 circles[outerIndex].remove();
    //                 //remove from circles array
    //                 circles.splice(innerIndex, 1);
    //                 circles.splice(outerIndex, 1);
    //             }
    //         }
    //     }
    // }
    // function mergeCirclesOnCollision(){
    //     for (var outerIndex = 0; outerIndex < circles.length - 1; outerIndex ++){
    //         for (var innerIndex = outerIndex + 1; innerIndex <= circles.length - 1; innerIndex++){
    //             var circle1Info = circles[outerIndex].info;
    //             var circle2Info = circles[innerIndex].info;
    //             if (distance([circle1Info.cx, circle1Info.cy],[circle2Info.cx, circle2Info.cy]) < circles[outerIndex].info.r + circles[innerIndex].info.r){
    //                 //circle collision event
    //                 console.log("detected collision - merging");

    //                 if (circles[outerIndex].info.r > circles[innerIndex].info.r){
    //                     //update first circle's radius
    //                     circles[outerIndex].info.r += circles[innerIndex].info.r;
    //                     //remove second circle from document
    //                     circles[innerIndex].remove();
    //                     //remove from circles array
    //                     circles.splice(innerIndex, 1);
    //                 } else {
    //                     circles[innerIndex].info.r += circles[outerIndex].info.r;
    //                     circles[outerIndex].remove();
    //                     circles.splice(outerIndex, 1);
    //                 }
    //             }
    //         }
    //     }
    // }

    //This one is still not working... balls just hit each other and stick together. I think I need to make sure that the bounce collision function doesn't execute more than once per actual collision. That might be what's giving me problems now. Anyways, I'll fix it later.
    function bounceOnCollision(){
        for (var outerIndex = 0; outerIndex < circles.length - 1; outerIndex ++){
            for (var innerIndex = outerIndex + 1; innerIndex <= circles.length - 1; innerIndex++){
                var circle1Info = circles[outerIndex].info;
                var circle2Info = circles[innerIndex].info;
                if (distance([circle1Info.cx, circle1Info.cy],[circle2Info.cx, circle2Info.cy]) < circle1Info.r + circle2Info.r){
                    //circle collision event
                    console.log("detected collision - bouncing");

                    var collisionPointX = ((circle1Info.cx * circle2Info.r) + (circle2Info.cx * circle1Info.r))/(circle1Info.r + circle2Info.r)
                    var collisionPointY = ((circle1Info.cy * circle2Info.r) + (circle2Info.cy * circle1Info.r))/(circle1Info.r + circle2Info.r)

                    var newVelXCircle1 = 
                    (circle1Info.velocity.x * 
                    (circle1Info.r/10 - circle2Info.r/10) + 
                    (2 * circle2Info.r/10 * circle2Info.velocity.x)) / 
                    (circle1Info.r/10 + circle2Info.r/10);

                    var newVelYCircle1 = 
                    (circle1Info.velocity.y * 
                    (circle1Info.r - circle2Info.r) + 
                    (2 * circle2Info.r * circle2Info.velocity.y)) / 
                    (circle1Info.r + circle2Info.r);

                    circles[outerIndex].info.velocity.x = newVelXCircle1;
                    circles[outerIndex].info.velocity.y = newVelYCircle1;

                    var newVelXCircle2 = (circle2Info.velocity.x * 
                    (circle2Info.r - circle1Info.r) + 
                    (2 * circle1Info.r * circle1Info.velocity.x)) / 
                    (circle1Info.r + circle2Info.r);

                    var newVelYCircle2 = (circle2Info.velocity.y * 
                    (circle2Info.r - circle1Info.r) + 
                    (2 * circle1Info.r * circle1Info.velocity.y)) / 
                    (circle1Info.r + circle2Info.r);

                    circles[innerIndex].info.velocity.x = newVelXCircle2;
                    circles[innerIndex].info.velocity.y = newVelYCircle2;

                    

                }
            }
        }
    }
    




    
}

	var playground = new PlayGround();
	setInterval(playground.loop, 15);

	var mousedown_time;

	function getTime(){
			var date = new Date();
			return date.getTime();
	}

	document.onmousedown = function(e){
			mousedown_time = getTime();
	}
	document.onmouseup = function(e){
			time_pressed = getTime() - mousedown_time;
			var radius = 5 + time_pressed/50;
			console.log("making new cicle with radius: " + radius + " at: (" + e.x + "," + e.y + ")")
			playground.createNewCircle(e.x, e.y, radius)
	}
	function setSVGsize(){
		console.log("called setSVGsize");
		var svg = document.getElementById("svg");
		svg.style.height = window.innerHeight;
		svg.style.width = window.innerWidth;
		console.log("New width: " + window.innerWidth);
		console.log("New height: " + window.innerHeight);
	}
	window.onresize = function(){
		console.log("triggered window resize event")
		setSVGsize();
}
//this function should take two points as arrays, [x_position, y_position]
function distance(point1, point2){
    return (Math.sqrt(Math.pow((point1[0] - point2[0]), 2) + Math.pow((point1[1] - point2[1]), 2)))
}
